/* ============================================================
 *  历史速记 · 高考历史知识点速记系统
 *  纯前端 / 无后端 / 无登录 · 分享链接直达（hash 路由）
 * ============================================================ */
(function () {
'use strict';

/* ---------------- 0. 常量与 DOM ---------------- */
var TAX = window.HIST_TAXONOMY || { eras: [] };
var META = window.HIST_META || { categories: [], levels: {}, freqLabel: {} };
var RAW = [].concat(
  window.HIST_DATA_CN_ANCIENT || [],
  window.HIST_DATA_CN_MODERN || [],
  window.HIST_DATA_WORLD_A || [],
  window.HIST_DATA_WORLD_B || []
);

var el = {};
['searchInput', 'searchClear', 'searchPop', 'btnQuiz', 'btnShare', 'btnTheme',
 'eraNav', 'periodChips', 'tlViewport', 'tlCanvas', 'minimap', 'mmTrack', 'mmView',
 'tlHint', 'panelTabs', 'panelBody', 'toast', 'shareOverlay', 'shareDesc',
 'shareLinkInput', 'shareCopy', 'shareScope', 'shareClose', 'zoomOut', 'zoomIn',
 'zoomFit', 'zoomVal', 'tabNumList', 'tabNumMarked'
].forEach(function (id) { el[id] = document.getElementById(id); });

var LANES = 3, H_GAP = 16, V_GAP = 8, C_PAD = 24, BASE_PPY = 0.52;
var MIN_SCALE = 0.35, MAX_SCALE = 6;

/* ---------------- 1. 存储 ---------------- */
var mem = {};
var LS = {
  get: function (k, d) {
    try {
      var v = localStorage.getItem(k);
      return v == null ? d : JSON.parse(v);
    } catch (e) { return k in mem ? mem[k] : d; }
  },
  set: function (k, v) {
    mem[k] = v;
    try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) {}
  }
};
var K_FAV = 'gh.fav.v1', K_KEEP = 'gh.keep.v1', K_WRONG = 'gh.wrong.v1', K_THEME = 'gh.theme.v1', K_STAT = 'gh.stat.v1';

var favSet = new Set((LS.get(K_FAV, []) || []).map(String));
var wrongSet = new Set((LS.get(K_WRONG, []) || []).map(String));
var keepMap = LS.get(K_KEEP, {}) || {};
var stat = LS.get(K_STAT, { done: 0, right: 0 }) || { done: 0, right: 0 };

function saveFav() { LS.set(K_FAV, Array.from(favSet)); }
function saveWrong() { LS.set(K_WRONG, Array.from(wrongSet)); }
function saveKeep() { LS.set(K_KEEP, keepMap); }

/* ---------------- 2. 数据整理 ---------------- */
var periodById = new Map(), eraById = new Map(), periods = [];

(TAX.eras || []).forEach(function (era, ei) {
  eraById.set(era.id, era);
  (era.periods || []).forEach(function (p) {
    var item = {
      id: p.id, name: p.name, range: p.range || [0, 0], feature: p.feature || '',
      eraId: era.id, eraName: era.name, side: era.side || 'cn',
      eraIndex: ei, order: periods.length
    };
    periods.push(item);
    periodById.set(p.id, item);
  });
});

function clamp(n, a, b) { return n < a ? a : (n > b ? b : n); }

function normalize(n) {
  if (!n || !n.id) return null;
  var p = periodById.get(n.periodId);
  var year = Number(n.year);
  if (!isFinite(year)) year = 0;
  var yearEnd = (n.yearEnd === null || n.yearEnd === undefined || n.yearEnd === '') ? null : Number(n.yearEnd);
  if (yearEnd !== null && !isFinite(yearEnd)) yearEnd = null;
  var cat = META.categories.some(function (c) { return c.id === n.category; }) ? n.category : '事件';
  var lv = ['核心', '重点', '了解'].indexOf(n.level) >= 0 ? n.level : '重点';
  var it = {
    id: String(n.id),
    era: p ? p.eraName : (n.era || ''),
    eraId: p ? p.eraId : '',
    side: p ? p.side : 'cn',
    period: p ? p.name : (n.period || ''),
    periodId: n.periodId || '',
    periodOrder: p ? p.order : 999,
    year: year, yearEnd: yearEnd,
    timeLabel: n.timeLabel || (year < 0 ? ('公元前' + (-year) + '年') : (year + '年')),
    title: n.title || '',
    category: cat,
    freq: clamp(Math.round(Number(n.freq) || 3), 1, 5),
    level: lv,
    core: n.core || '',
    pts: Array.isArray(n.points) ? n.points.filter(Boolean) : [],
    mnemonic: n.mnemonic || '',
    confuse: (Array.isArray(n.confuse) ? n.confuse : []).filter(function (c) { return c && (c.a || c.b); })
  };
  it.search = (it.title + ' ' + it.core + ' ' + it.period + ' ' + it.era + ' ' + it.category + ' ' +
    it.timeLabel + ' ' + it.pts.join(' ') + ' ' + it.mnemonic + ' ' +
    it.confuse.map(function (c) { return (c.a || '') + (c.b || '') + (c.note || ''); }).join(' ')).toLowerCase();
  return it;
}

var POINTS = RAW.map(normalize).filter(Boolean);
POINTS.sort(function (a, b) {
  if (a.periodOrder !== b.periodOrder) return a.periodOrder - b.periodOrder;
  if (a.year !== b.year) return a.year - b.year;
  return a.id < b.id ? -1 : 1;
});

var byId = new Map();
POINTS.forEach(function (p) { byId.set(p.id, p); });

/* 章节 = 时期 */
var chapters = periods.map(function (pd) {
  return {
    pd: pd, id: pd.id, name: pd.name, range: pd.range, side: pd.side,
    eraId: pd.eraId, eraName: pd.eraName, eraIndex: pd.eraIndex, feature: pd.feature,
    items: [], x: 0, width: 0, placed: []
  };
});
var chById = new Map();
chapters.forEach(function (c) { chById.set(c.id, c); });
POINTS.forEach(function (p) {
  var c = chById.get(p.periodId);
  if (c) c.items.push(p);
});

var QUIZ_POOL_LABEL = {};

/* ---------------- 3. 状态 ---------------- */
var state = {
  eraId: 'all',
  periodId: null,
  scale: 1,
  activeId: null,
  panel: 'detail',
  query: '',
  listFreq: 0,
  listLevel: 'all',
  listSort: 'time',
  cmpA: '', cmpB: '',
  quizRange: 'all', quizMode: 'choice', quizCount: 10
};
var QS = null;
var layoutById = new Map();
var metrics = { nodeW: 176, nodeH: 78, axisH: 46 };

/* ---------------- 4. 工具函数 ---------------- */
function esc(s) {
  return String(s == null ? '' : s)
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}
function hl(s) {
  var t = esc(s);
  var q = state.query.trim();
  if (!q) return t;
  try {
    var re = new RegExp('(' + q.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + ')', 'gi');
    return t.replace(re, '<mark class="hit">$1</mark>');
  } catch (e) { return t; }
}
function catColor(c) {
  var it = META.categories.filter(function (x) { return x.id === c; })[0];
  return it ? it.color : '#8a8076';
}
function catIcon(c) {
  var it = META.categories.filter(function (x) { return x.id === c; })[0];
  return it ? it.icon : '◆';
}
function freqHtml(f) {
  var s = '<span class="freq" title="考频 ' + f + '/5 · ' + (META.freqLabel[f] || '') + '">';
  for (var i = 1; i <= 5; i++) s += '<i class="' + (i <= f ? 'on' : '') + '"></i>';
  return s + '</span>';
}
function levelHtml(lv) {
  return '<span class="lv-badge lv-' + lv + '">' + lv + '</span>';
}
function toast(msg, ms) {
  var t = el.toast;
  t.textContent = msg;
  t.hidden = false;
  clearTimeout(toast._t);
  toast._t = setTimeout(function () { t.hidden = true; }, ms || 1900);
}
function readMetrics() {
  var cs = getComputedStyle(document.documentElement);
  function px(name, fb) {
    var v = parseFloat(cs.getPropertyValue(name));
    return isFinite(v) && v > 0 ? v : fb;
  }
  metrics.nodeW = px('--node-w', 176);
  metrics.nodeH = px('--node-h', 78);
  metrics.axisH = px('--tl-axis-h', 46);
}

/* ---------------- 5. 时间轴布局 ---------------- */
function visibleChapters() {
  return chapters.filter(function (c) {
    if (state.eraId !== 'all' && c.eraId !== state.eraId) return false;
    if (c.items.length === 0) return false;
    return true;
  });
}

function layoutChapter(c, scale) {
  var ppy = BASE_PPY * scale;
  var start = c.range[0];
  var laneRight = [-1e9, -1e9, -1e9];
  var placed = [];
  var maxRight = 0;
  c.items.forEach(function (it) {
    var ideal = Math.max(0, (it.year - start) * ppy);
    var lane = 0, bestX = Infinity;
    for (var i = 0; i < LANES; i++) {
      var x = Math.max(ideal, laneRight[i] + H_GAP);
      if (x < bestX) { bestX = x; lane = i; }
    }
    var nx = Math.max(ideal, laneRight[lane] + H_GAP, 0);
    laneRight[lane] = nx + metrics.nodeW;
    if (laneRight[lane] > maxRight) maxRight = laneRight[lane];
    placed.push({ it: it, lane: lane, x: nx });
  });
  return { placed: placed, width: Math.max(maxRight, metrics.nodeW) + C_PAD * 2 };
}

function doLayout(scale) {
  var list = visibleChapters();
  var x = 0;
  layoutById = new Map();
  list.forEach(function (c) {
    var L = layoutChapter(c, scale);
    c.placed = L.placed;
    c.width = L.width;
    c.x = x;
    x += L.width;
    L.placed.forEach(function (pc) {
      layoutById.set(pc.it.id, { ch: c, x: c.x + C_PAD + pc.x, lane: pc.lane });
    });
  });
  return x;
}

function yearSpanLabel(range) {
  function y(v) { return v < 0 ? ('前' + (-v)) : String(v); }
  return y(range[0]) + ' — ' + y(range[1]);
}

function renderTimeline() {
  var totalW = doLayout(state.scale);
  var canvasH = metrics.axisH + LANES * (metrics.nodeH + V_GAP) + 6;
  var vp = el.tlViewport;
  vp.style.height = canvasH + 'px';

  var list = visibleChapters();
  var h = [];
  h.push('<div class="tl-axisline"></div>');

  list.forEach(function (c) {
    h.push('<div class="band side-' + c.side + '" style="left:' + c.x.toFixed(1) + 'px;width:' + c.width.toFixed(1) + 'px">');
    h.push('<span class="band-label" title="' + esc(c.name + ' ' + yearSpanLabel(c.range)) + '">' + esc(c.name) + '</span>');
    h.push('<span class="band-range">' + esc(yearSpanLabel(c.range)) + '</span>');
    h.push('</div>');
  });

  list.forEach(function (c) {
    c.placed.forEach(function (pc) {
      var it = pc.it;
      var matched = !state.query || it.search.indexOf(state.query.toLowerCase()) >= 0;
      var cls = 'node' + (it.id === state.activeId ? ' is-active' : '') +
        (state.query ? (matched ? ' is-hit' : ' is-dim') : '');
      var top = metrics.axisH + V_GAP / 2 + pc.lane * (metrics.nodeH + V_GAP);
      h.push('<article class="' + cls + '" data-id="' + esc(it.id) + '" style="left:' +
        (c.x + C_PAD + pc.x).toFixed(1) + 'px;top:' + top.toFixed(1) + 'px">');
      h.push('<div class="node-time">' + esc(it.timeLabel) +
        (favSet.has(it.id) ? '<span class="node-star" style="margin-left:auto">★</span>' : '') + '</div>');
      h.push('<div class="node-title">' + hl(it.title) + '</div>');
      h.push('<div class="node-foot">' + freqHtml(it.freq) +
        '<span class="cat-dot" style="background:' + catColor(it.category) + '" title="' + esc(it.category) + '"></span>' +
        levelHtml(it.level) + '</div>');
      h.push('</article>');
    });
  });

  el.tlCanvas.style.width = totalW + 'px';
  el.tlCanvas.innerHTML = h.join('');
  renderMinimap();
}

/* ---------------- 6. 缩略导航 ---------------- */
function renderMinimap() {
  var list = visibleChapters();
  var total = 0;
  list.forEach(function (c) { total += c.width; });
  if (!total) { el.mmTrack.innerHTML = ''; return; }
  var h = [];
  list.forEach(function (c) {
    h.push('<div class="mm-seg side-' + c.side + '" style="flex:' + c.width.toFixed(1) +
      ' 0 0" title="' + esc(c.name) + '"></div>');
  });
  el.mmTrack.innerHTML = h.join('');
  syncMinimap();
}
function syncMinimap() {
  var vp = el.tlViewport;
  var contentW = parseFloat(el.tlCanvas.style.width) || 1;
  var trackW = el.mmTrack.clientWidth || 1;
  var w = Math.max(12, vp.clientWidth / contentW * trackW);
  var left = vp.scrollLeft / contentW * trackW;
  el.mmView.style.width = w + 'px';
  el.mmView.style.left = clamp(left, 0, Math.max(0, trackW - w)) + 'px';
}

/* ---------------- 7. 滚动 / 缩放 ---------------- */
function centerAnchor() {
  var vp = el.tlViewport;
  var cx = vp.scrollLeft + vp.clientWidth / 2;
  var list = visibleChapters();
  var ch = list[0] || null;
  for (var i = 0; i < list.length; i++) {
    if (cx >= list[i].x && cx < list[i].x + list[i].width) { ch = list[i]; break; }
    if (cx >= list[i].x) ch = list[i];
  }
  if (!ch) return null;
  return { id: ch.id, ratio: ch.width ? (cx - ch.x) / ch.width : 0.5 };
}
function applyAnchor(a) {
  if (!a) return;
  var ch = chById.get(a.id);
  if (!ch) return;
  var vp = el.tlViewport;
  vp.scrollLeft = ch.x + a.ratio * ch.width - vp.clientWidth / 2;
}

function setScale(s, anchor) {
  var ns = clamp(s, MIN_SCALE, MAX_SCALE);
  if (Math.abs(ns - state.scale) < 0.001) return;
  var a = anchor || centerAnchor();
  state.scale = ns;
  renderTimeline();
  applyAnchor(a);
  el.zoomVal.textContent = Math.round(ns * 100) + '%';
  updateZoomButtons();
}
function updateZoomButtons() {
  el.zoomOut.disabled = state.scale <= MIN_SCALE + 0.001;
  el.zoomIn.disabled = state.scale >= MAX_SCALE - 0.001;
}
function fitScale() {
  var list = visibleChapters();
  if (!list.length) return 1;
  var lo = MIN_SCALE, hi = MAX_SCALE;
  for (var i = 0; i < 12; i++) {
    var mid = (lo + hi) / 2;
    var w = 0;
    list.forEach(function (c) { w += layoutChapter(c, mid).width; });
    if (w > el.tlViewport.clientWidth) hi = mid; else lo = mid;
  }
  return (lo + hi) / 2;
}
function scrollToPeriod(pid, opt) {
  var c = chById.get(pid);
  if (!c) return;
  if (state.eraId !== 'all' && state.eraId !== c.eraId) {
    state.eraId = c.eraId;
    renderEraNav();
  }
  renderTimeline();
  var vp = el.tlViewport;
  vp.scrollTo({ left: Math.max(0, c.x - 10), behavior: (opt && opt.instant) ? 'auto' : 'smooth' });
  state.periodId = pid;
  renderPeriodChips();
  highlightChip(pid);
}
function scrollToPoint(id) {
  var loc = layoutById.get(id);
  if (!loc) return;
  var vp = el.tlViewport;
  var left = loc.x - vp.clientWidth / 2 + metrics.nodeW / 2;
  vp.scrollTo({ left: Math.max(0, left), behavior: 'smooth' });
}

/* ---------------- 8. 顶部导航 ---------------- */
function renderEraNav() {
  var h = ['<button class="era-tab' + (state.eraId === 'all' ? ' is-active' : '') +
    '" data-era="all">全部史别</button>'];
  (TAX.eras || []).forEach(function (era) {
    var n = POINTS.filter(function (p) { return p.eraId === era.id; }).length;
    h.push('<button class="era-tab' + (state.eraId === era.id ? ' is-active' : '') +
      '" data-era="' + esc(era.id) + '"><span class="era-dot" style="background:' +
      (era.side === 'cn' ? '#b03a2e' : '#1f5c8b') + '"></span>' + esc(era.name) +
      '<span class="chip-n">' + n + '</span></button>');
  });
  el.eraNav.innerHTML = h.join('');
}

function renderPeriodChips() {
  var h = [];
  (TAX.eras || []).forEach(function (era, i) {
    if (state.eraId !== 'all' && state.eraId !== era.id) return;
    if (i > 0 && h.length) h.push('<span class="chip-sep"></span>');
    (era.periods || []).forEach(function (p) {
      var ch = chById.get(p.id);
      if (!ch || !ch.items.length) return;
      h.push('<button class="chip' + (state.periodId === p.id ? ' is-active' : '') +
        '" data-pid="' + esc(p.id) + '">' + esc(p.name) +
        '<span class="chip-n">' + ch.items.length + '</span></button>');
    });
  });
  el.periodChips.innerHTML = h.join('');
}
function highlightChip(pid) {
  var nodes = el.periodChips.querySelectorAll('.chip');
  for (var i = 0; i < nodes.length; i++) {
    var on = nodes[i].getAttribute('data-pid') === pid;
    nodes[i].className = 'chip' + (on ? ' is-active' : '');
    if (on && nodes[i].scrollIntoView) {
      nodes[i].scrollIntoView({ block: 'nearest', inline: 'center', behavior: 'smooth' });
    }
  }
}

/* ---------------- 9. 面板：详情 ---------------- */
function renderDetail() {
  var p = state.activeId ? byId.get(state.activeId) : null;
  if (!p) {
    el.panelBody.innerHTML = '<div class="empty"><span class="big">史</span>' +
      '点击上方时间轴上的知识点卡片，查看核心记忆点、要点、口诀与易混辨析。<br>' +
      '也可以在搜索框中输入「科举制」「马歇尔计划」等关键词快速定位。</div>';
    return;
  }
  var keeps = keepMap[p.id] || [];
  var samePeriod = (chById.get(p.periodId) || { items: [] }).items.filter(function (x) { return x.id !== p.id; });

  var h = [];
  h.push('<div class="detail-head">');
  h.push('<div class="detail-meta">');
  h.push('<span class="pill time">' + esc(p.timeLabel) + '</span>');
  h.push('<span class="pill">' + esc(p.era) + ' · ' + esc(p.period) + '</span>');
  h.push('<span class="pill"><span class="cat-dot" style="display:inline-block;background:' + catColor(p.category) + '"></span> ' + esc(p.category) + '</span>');
  h.push('<span class="pill">考频 ' + p.freq + '/5 · ' + (META.freqLabel[p.freq] || '') + '</span>');
  h.push(levelHtml(p.level));
  h.push(freqHtml(p.freq));
  h.push('</div>');
  h.push('<h2 class="detail-title">' + hl(p.title) + '</h2>');
  h.push('<div class="detail-period">所属时期：<a href="#/period/' + esc(p.periodId) + '" data-pid="' + esc(p.periodId) + '">' + esc(p.period) + '</a>');
  if (p.yearEnd) h.push(' · 持续至 ' + esc(fmtYear(p.yearEnd)));
  h.push('</div></div>');

  if (p.core) {
    h.push('<div class="sec"><div class="core-box"><span class="tag">核心记忆点</span>' + hl(p.core) + '</div></div>');
  }
  if (p.pts.length) {
    h.push('<div class="sec"><div class="sec-title">要点梳理<span class="cnt">共 ' + p.pts.length + ' 条 · 点击可高亮标记</span></div>');
    h.push('<ul class="pts-list">');
    p.pts.forEach(function (t, i) {
      h.push('<li class="markable' + (keeps.indexOf(i) >= 0 ? ' keep' : '') + '" data-keep="' + i + '" title="点击标记/取消高亮">' + hl(t) + '</li>');
    });
    h.push('</ul></div>');
  }
  if (p.mnemonic) {
    h.push('<div class="sec"><div class="sec-title">记忆口诀</div>' +
      '<div class="mnemonic-box">' + hl(p.mnemonic) + '</div></div>');
  }
  if (p.confuse.length) {
    h.push('<div class="sec"><div class="sec-title">易混点辨析<span class="cnt">共 ' + p.confuse.length + ' 组</span></div>');
    p.confuse.forEach(function (c) { h.push(confuseHtml(c)); });
    h.push('</div>');
  }
  if (samePeriod.length) {
    h.push('<div class="sec"><div class="sec-title">同阶段考点<span class="cnt">' + esc(p.period) + '</span></div><div class="rel-wrap">');
    samePeriod.slice(0, 12).forEach(function (x) {
      h.push('<button class="rel-item" data-goto="' + esc(x.id) + '" title="' + esc(x.timeLabel) + '">' + esc(x.title) + '</button>');
    });
    h.push('</div></div>');
  }
  h.push('<div class="detail-actions">');
  h.push('<button class="btn primary" data-act="fav">' + (favSet.has(p.id) ? '★ 已标记' : '☆ 标记为重点') + '</button>');
  h.push('<button class="btn" data-act="share">分享此知识点</button>');
  h.push('<button class="btn" data-act="cmp">加入对比台</button>');
  h.push('<button class="btn" data-act="quiz">抽背这个知识点</button>');
  if (wrongSet.has(p.id)) h.push('<button class="btn" data-act="unwrong">从错题本移除</button>');
  h.push('</div>');

  el.panelBody.innerHTML = h.join('');
  el.panelBody.scrollTop = 0;
}

function fmtYear(y) { return y < 0 ? ('公元前 ' + (-y) + ' 年') : (y + ' 年'); }

function confuseHtml(c) {
  return '<div class="confuse-card"><div class="confuse-pair">' +
    '<div class="confuse-side a">' + esc(c.a || '') + '</div>' +
    '<div class="confuse-vs">VS</div>' +
    '<div class="confuse-side b">' + esc(c.b || '') + '</div>' +
    '</div>' + (c.note ? '<div class="confuse-note">' + esc(c.note) + '</div>' : '') + '</div>';
}

/* ---------------- 10. 面板：速记卡列表 ---------------- */
function filteredList() {
  var q = state.query.trim().toLowerCase();
  var list = POINTS.filter(function (p) {
    if (state.eraId !== 'all' && p.eraId !== state.eraId) return false;
    if (state.periodId && p.periodId !== state.periodId) return false;
    if (state.listFreq && p.freq < state.listFreq) return false;
    if (state.listLevel !== 'all' && p.level !== state.listLevel) return false;
    if (q && p.search.indexOf(q) < 0) return false;
    return true;
  });
  if (state.listSort === 'freq') {
    list.sort(function (a, b) { return b.freq - a.freq || a.periodOrder - b.periodOrder || a.year - b.year; });
  }
  return list;
}

function renderList() {
  var list = filteredList();
  var h = [];
  h.push('<div class="list-toolbar">');
  h.push('<div class="filter-group">');
  [0, 5, 4, 3].forEach(function (f) {
    var label = f === 0 ? '全部考频' : (f === 5 ? '★★★★★ 必考' : (f === 4 ? '★★★★+ 高频' : '★★★+ 常考'));
    h.push('<button class="fbtn' + (state.listFreq === f ? ' is-active' : '') + '" data-freq="' + f + '">' + label + '</button>');
  });
  h.push('</div><div class="filter-group">');
  [['all', '全部等级'], ['核心', '核心考点'], ['重点', '重点'], ['了解', '了解']].forEach(function (x) {
    h.push('<button class="fbtn' + (state.listLevel === x[0] ? ' is-active' : '') + '" data-level="' + x[0] + '">' + x[1] + '</button>');
  });
  h.push('</div><div class="filter-group">');
  h.push('<button class="fbtn' + (state.listSort === 'time' ? ' is-active' : '') + '" data-sort="time">按时间</button>');
  h.push('<button class="fbtn' + (state.listSort === 'freq' ? ' is-active' : '') + '" data-sort="freq">按考频</button>');
  h.push('</div>');
  h.push('<span class="count-note">共 ' + list.length + ' 条' +
    (state.periodId ? ' · ' + esc((chById.get(state.periodId) || {}).name || '') : '') + '</span>');
  h.push('</div>');

  var introCh = state.periodId ? chById.get(state.periodId) : null;
  if (introCh && introCh.feature) {
    h.push('<div class="period-intro"><b>' + esc(introCh.name) + ' · 阶段特征</b>' + esc(introCh.feature) + '</div>');
  } else if (state.eraId !== 'all') {
    var era = eraById.get(state.eraId);
    if (era && era.desc) h.push('<div class="period-intro"><b>' + esc(era.name) + ' · 知识脉络</b>' + esc(era.desc) + '</div>');
  }

  if (!list.length) {
    h.push('<div class="empty"><span class="big">空</span>当前筛选条件下没有知识点，换个条件试试。</div>');
  } else {
    h.push('<div id="cardList">');
    list.forEach(function (p) { h.push(cardHtml(p)); });
    h.push('</div>');
  }
  el.panelBody.innerHTML = h.join('');
  el.panelBody.scrollTop = 0;
}

function cardHtml(p) {
  var keeps = keepMap[p.id] || [];
  var h = ['<div class="card" data-cid="' + esc(p.id) + '">'];
  h.push('<div class="card-head" data-toggle="' + esc(p.id) + '">');
  h.push('<div class="card-time">' + esc(p.timeLabel) + '</div>');
  h.push('<div class="card-main"><div class="card-title">' + hl(p.title) + '</div>' +
    '<div class="card-sub">' + esc(p.era) + ' · ' + esc(p.period) + ' · ' + esc(p.category) + '</div></div>');
  h.push('<div class="card-badges">' + levelHtml(p.level) + freqHtml(p.freq) +
    (favSet.has(p.id) ? '<span style="color:var(--gold)">★</span>' : '') + '</div>');
  h.push('</div>');
  h.push('<div class="card-body" hidden>');
  if (p.core) h.push('<div class="sec"><div class="core-box"><span class="tag">核心记忆点</span>' + hl(p.core) + '</div></div>');
  if (p.pts.length) {
    h.push('<div class="sec"><div class="sec-title">要点梳理</div><ul class="pts-list">');
    p.pts.forEach(function (t, i) {
      h.push('<li class="markable' + (keeps.indexOf(i) >= 0 ? ' keep' : '') + '" data-keep="' + i + '">' + hl(t) + '</li>');
    });
    h.push('</ul></div>');
  }
  if (p.mnemonic) h.push('<div class="sec"><div class="sec-title">记忆口诀</div><div class="mnemonic-box">' + hl(p.mnemonic) + '</div></div>');
  if (p.confuse.length) {
    h.push('<div class="sec"><div class="sec-title">易混点辨析</div>');
    p.confuse.forEach(function (c) { h.push(confuseHtml(c)); });
    h.push('</div>');
  }
  h.push('<div class="detail-actions">' +
    '<button class="btn" data-act="fav" data-id="' + esc(p.id) + '">' + (favSet.has(p.id) ? '★ 已标记' : '☆ 标记为重点') + '</button>' +
    '<button class="btn" data-act="share" data-id="' + esc(p.id) + '">分享</button>' +
    '<button class="btn" data-act="detail" data-id="' + esc(p.id) + '">在时间轴定位</button>' +
    '</div>');
  h.push('</div></div>');
  return h.join('');
}

/* ---------------- 11. 面板：易混对比 ---------------- */
function renderCompare() {
  var h = [];
  h.push('<div class="sec"><div class="sec-title">对比台<span class="cnt">任选两个知识点逐项对照</span></div>');
  h.push('<div class="compare-picker">');
  h.push('<select id="cmpA">' + optionHtml(state.cmpA) + '</select>');
  h.push('<select id="cmpB">' + optionHtml(state.cmpB) + '</select>');
  h.push('<button class="btn" data-act="cmpSwap">互换</button>');
  h.push('</div>');
  var A = state.cmpA ? byId.get(state.cmpA) : null;
  var B = state.cmpB ? byId.get(state.cmpB) : null;
  if (A || B) {
    h.push('<div class="cmp-grid">');
    h.push(cmpCol(A, 'a'));
    h.push(cmpCol(B, 'b'));
    h.push('</div>');
  }
  h.push('</div>');

  var q = state.query.trim().toLowerCase();
  var groups = [];
  POINTS.forEach(function (p) {
    if (state.eraId !== 'all' && p.eraId !== state.eraId) return;
    p.confuse.forEach(function (c) {
      var text = ((c.a || '') + (c.b || '') + (c.note || '') + p.title).toLowerCase();
      if (q && text.indexOf(q) < 0) return;
      groups.push({ p: p, c: c });
    });
  });
  h.push('<div class="sec"><div class="sec-title">易混点清单<span class="cnt">共 ' + groups.length + ' 组</span></div>');
  if (!groups.length) {
    h.push('<div class="empty"><span class="big">辨</span>没有匹配的易混点。</div>');
  } else {
    groups.forEach(function (g) {
      h.push(confuseHtml(g.c));
      h.push('<div style="margin:-6px 0 12px;font-size:12px;color:var(--ink-3)">' +
        '出自：<button class="rel-item" data-goto="' + esc(g.p.id) + '">' + esc(g.p.title) + '</button> ' +
        '<span>' + esc(g.p.period) + '</span></div>');
    });
  }
  h.push('</div>');
  el.panelBody.innerHTML = h.join('');
  el.panelBody.scrollTop = 0;
}

function optionHtml(sel) {
  var h = ['<option value="">— 选择知识点 —</option>'];
  var lastEra = '';
  POINTS.forEach(function (p) {
    if (p.era !== lastEra) {
      if (lastEra) h.push('</optgroup>');
      h.push('<optgroup label="' + esc(p.era) + '">');
      lastEra = p.era;
    }
    h.push('<option value="' + esc(p.id) + '"' + (sel === p.id ? ' selected' : '') + '>' +
      esc(p.timeLabel + ' · ' + p.title) + '</option>');
  });
  if (lastEra) h.push('</optgroup>');
  return h.join('');
}

function cmpCol(p, cls) {
  var h = ['<div class="cmp-col ' + cls + '"><h4>' + (p ? esc(p.title) : '未选择') + '</h4>'];
  if (p) {
    h.push('<div class="cmp-row"><span class="k">时间</span>' + esc(p.timeLabel) + '</div>');
    h.push('<div class="cmp-row"><span class="k">时期</span>' + esc(p.era) + ' · ' + esc(p.period) + '</div>');
    h.push('<div class="cmp-row"><span class="k">类别 / 考频</span>' + esc(p.category) + ' · ' + p.freq + '/5 · ' + esc(p.level) + '</div>');
    h.push('<div class="cmp-row"><span class="k">核心记忆点</span>' + esc(p.core) + '</div>');
    h.push('<div class="cmp-row"><span class="k">要点</span><ul class="pts-list" style="padding-left:0">' +
      p.pts.map(function (t) { return '<li style="font-size:13px;padding-left:0">' + esc(t) + '</li>'; }).join('') + '</ul></div>');
    if (p.mnemonic) h.push('<div class="cmp-row"><span class="k">口诀</span>' + esc(p.mnemonic) + '</div>');
  }
  h.push('</div>');
  return h.join('');
}

/* ---------------- 12. 面板：口诀 ---------------- */
function renderMnemonic() {
  var list = POINTS.filter(function (p) {
    if (!p.mnemonic) return false;
    if (state.eraId !== 'all' && p.eraId !== state.eraId) return false;
    if (state.periodId && p.periodId !== state.periodId) return false;
    var q = state.query.trim().toLowerCase();
    if (q && p.search.indexOf(q) < 0) return false;
    return true;
  });
  var h = [];
  h.push('<div class="sec-title">记忆口诀速查<span class="cnt">共 ' + list.length + ' 条 · 按时期顺序</span></div>');
  if (!list.length) {
    h.push('<div class="empty"><span class="big">诀</span>当前范围内没有口诀，试试切换到其他史别。</div>');
  } else {
    h.push('<div style="margin-top:12px">');
    list.forEach(function (p) {
      h.push('<div class="card"><div class="card-head" data-goto="' + esc(p.id) + '">' +
        '<div class="card-time">' + esc(p.timeLabel) + '</div>' +
        '<div class="card-main"><div class="card-title">' + hl(p.title) + '</div>' +
        '<div class="mnemonic-box" style="margin-top:7px;font-size:14.5px">' + hl(p.mnemonic) + '</div>' +
        (p.core ? '<div class="card-sub" style="margin-top:6px">核心：' + hl(p.core) + '</div>' : '') +
        '</div><div class="card-badges">' + levelHtml(p.level) + freqHtml(p.freq) + '</div>' +
        '</div></div>');
    });
    h.push('</div>');
  }
  el.panelBody.innerHTML = h.join('');
  el.panelBody.scrollTop = 0;
}

/* ---------------- 13. 面板：随机抽背 ---------------- */
function quizPool() {
  var r = state.quizRange;
  if (r === 'era') return POINTS.filter(function (p) { return state.eraId === 'all' || p.eraId === state.eraId; });
  if (r === 'period') return POINTS.filter(function (p) { return state.periodId ? p.periodId === state.periodId : true; });
  if (r === 'top') return POINTS.filter(function (p) { return p.freq >= 4; });
  if (r === 'core') return POINTS.filter(function (p) { return p.level === '核心'; });
  if (r === 'fav') return POINTS.filter(function (p) { return favSet.has(p.id); });
  if (r === 'wrong') return POINTS.filter(function (p) { return wrongSet.has(p.id); });
  return POINTS.slice();
}
function shuffle(a) {
  var x = a.slice();
  for (var i = x.length - 1; i > 0; i--) {
    var j = Math.floor(Math.random() * (i + 1));
    var t = x[i]; x[i] = x[j]; x[j] = t;
  }
  return x;
}
function distractors(p, pool) {
  var same = pool.filter(function (x) { return x.id !== p.id && x.periodId === p.periodId; });
  var out = shuffle(same).slice(0, 3);
  if (out.length < 3) {
    var extra = shuffle(pool.filter(function (x) {
      return x.id !== p.id && x.eraId === p.eraId && out.indexOf(x) < 0;
    })).slice(0, 3 - out.length);
    out = out.concat(extra);
  }
  if (out.length < 3) {
    var g = shuffle(POINTS.filter(function (x) {
      return x.id !== p.id && x.title !== p.title && out.indexOf(x) < 0;
    })).slice(0, 3 - out.length);
    out = out.concat(g);
  }
  return out;
}
function buildQuiz() {
  var pool = quizPool();
  if (pool.length < 2) { toast('该范围内知识点太少，无法抽背'); return; }
  var n = state.quizCount === 0 ? pool.length : Math.min(state.quizCount, pool.length);
  var picked = shuffle(pool).slice(0, n);
  var qs = picked.map(function (p) {
    if (state.quizMode === 'recall') return { type: 'recall', p: p, revealed: false, ok: null };
    var stem = p.pts.length ? p.pts[0] : (p.core || p.title);
    var opts = shuffle([{ id: p.id, text: p.title }].concat(
      distractors(p, pool).map(function (x) { return { id: x.id, text: x.title }; })
    ));
    return { type: 'choice', p: p, stem: stem, opts: opts, picked: null };
  });
  QS = { qs: qs, i: 0, right: 0, wrong: 0, mode: state.quizMode, finished: false };
  renderQuiz();
}

function renderQuiz() {
  if (!QS) return renderQuizSetup();
  if (QS.finished) return renderQuizResult();
  var q = QS.qs[QS.i];
  var h = [];
  h.push('<div class="quiz-card">');
  h.push('<div class="quiz-progress">第 ' + (QS.i + 1) + ' / ' + QS.qs.length + ' 题 · ' +
    (q.type === 'choice' ? '选择题' : '自测回忆') + ' · ' + esc(q.p.timeLabel) + ' · ' + esc(q.p.period) + '</div>');

  if (q.type === 'choice') {
    h.push('<p class="quiz-q"><b>下列内容描述的是哪一个历史知识点？</b><br>' + esc(q.stem) + '</p>');
    h.push('<div class="quiz-opts">');
    q.opts.forEach(function (o) {
      var cls = 'quiz-opt';
      if (q.picked) {
        if (o.id === q.p.id) cls += ' correct';
        else if (o.id === q.picked) cls += ' wrong';
      }
      h.push('<button class="' + cls + '" data-opt="' + esc(o.id) + '"' + (q.picked ? ' disabled' : '') + '>' + esc(o.text) + '</button>');
    });
    h.push('</div>');
    if (q.picked) {
      h.push('<div class="quiz-ans"><b>正确答案：' + esc(q.p.title) + '</b><br>' +
        '核心记忆点：' + esc(q.p.core) + '</div>');
      h.push('<div class="quiz-foot">' +
        '<button class="btn primary" data-act="qNext">' + (QS.i + 1 >= QS.qs.length ? '查看结果' : '下一题') + '</button>' +
        '<button class="btn" data-act="qOpen">在时间轴查看</button>' +
        '<span class="quiz-stat">答对 ' + QS.right + ' · 答错 ' + QS.wrong + '</span></div>');
    } else {
      h.push('<div class="quiz-foot"><button class="btn ghost" data-act="qQuit">结束抽背</button>' +
        '<span class="quiz-stat">累计答对 ' + QS.right + ' · 答错 ' + QS.wrong + '</span></div>');
    }
  } else {
    h.push('<p class="quiz-q">' + esc(q.p.title) + '</p>');
    h.push('<div style="font-size:13px;color:var(--ink-3)">先在心里回忆它的核心记忆点和要点，再点开核对。</div>');
    if (!q.revealed) {
      h.push('<div class="quiz-foot"><button class="btn primary" data-act="qShow">显示答案</button>' +
        '<button class="btn ghost" data-act="qQuit">结束抽背</button>' +
        '<span class="quiz-stat">已复习 ' + (QS.i) + ' 题</span></div>');
    } else {
      h.push('<div class="sec"><div class="core-box"><span class="tag">核心记忆点</span>' + esc(q.p.core) + '</div></div>');
      if (q.p.pts.length) {
        h.push('<ul class="pts-list">' + q.p.pts.map(function (t) { return '<li>' + esc(t) + '</li>'; }).join('') + '</ul>');
      }
      if (q.p.mnemonic) h.push('<div class="mnemonic-box">' + esc(q.p.mnemonic) + '</div>');
      h.push('<div class="quiz-foot">' +
        '<button class="btn primary" data-act="qOk">记住了</button>' +
        '<button class="btn" data-act="qNo">没记住</button>' +
        '<span class="quiz-stat">已复习 ' + (QS.i + 1) + ' 题</span></div>');
    }
  }
  h.push('</div>');
  el.panelBody.innerHTML = h.join('');
}

function renderQuizSetup() {
  var h = [];
  var ranges = [
    ['all', '全部知识点'], ['era', '当前史别'], ['period', '当前时期'],
    ['top', '高频考点（考频≥4）'], ['core', '核心考点'], ['fav', '我的标记'], ['wrong', '错题本']
  ];
  var modes = [['choice', '选择题'], ['recall', '自测回忆']];
  var counts = [[10, '10 题'], [20, '20 题'], [0, '全部']];

  h.push('<div class="quiz-setup">');
  h.push('<div class="sec-title">随机抽背<span class="cnt">从选定的范围里随机出题，错题自动进入错题本</span></div>');
  h.push('<div class="quiz-row"><span class="lbl">范围</span><div class="filter-group">');
  ranges.forEach(function (x) {
    var n = null;
    h.push('<button class="fbtn' + (state.quizRange === x[0] ? ' is-active' : '') + '" data-qrange="' + x[0] + '">' + x[1] + '</button>');
  });
  h.push('</div></div>');
  h.push('<div class="quiz-row"><span class="lbl">题型</span><div class="filter-group">');
  modes.forEach(function (x) {
    h.push('<button class="fbtn' + (state.quizMode === x[0] ? ' is-active' : '') + '" data-qmode="' + x[0] + '">' + x[1] + '</button>');
  });
  h.push('</div></div>');
  h.push('<div class="quiz-row"><span class="lbl">题量</span><div class="filter-group">');
  counts.forEach(function (x) {
    h.push('<button class="fbtn' + (state.quizCount === x[0] ? ' is-active' : '') + '" data-qcount="' + x[0] + '">' + x[1] + '</button>');
  });
  h.push('</div></div>');
  var n = quizPool().length;
  h.push('<div class="quiz-row"><button class="btn primary" data-act="qStart">开始抽背（题库 ' + n + ' 条）</button>');
  h.push('<span class="quiz-stat">累计练习 ' + stat.done + ' 题 · 正确率 ' +
    (stat.done ? Math.round(stat.right / stat.done * 100) : 0) + '%</span></div>');
  h.push('</div>');
  el.panelBody.innerHTML = h.join('');
  el.panelBody.scrollTop = 0;
}

function renderQuizResult() {
  var total = QS.qs.length;
  var rate = total ? Math.round(QS.right / total * 100) : 0;
  var wrongs = QS.qs.filter(function (q) {
    return q.type === 'choice' ? q.picked && q.picked !== q.p.id : q.ok === false;
  });
  var h = [];
  h.push('<div class="quiz-card">');
  h.push('<p class="quiz-q">本轮完成 · 正确率 ' + rate + '%</p>');
  h.push('<div class="quiz-progress">共 ' + total + ' 题 · 记住 ' + QS.right + ' · 未掌握 ' + wrongs.length + '</div>');
  h.push('<div class="quiz-foot"><button class="btn primary" data-act="qStart">再来一轮</button>' +
    '<button class="btn" data-act="qBack">返回设置</button></div>');
  h.push('</div>');
  if (wrongs.length) {
    h.push('<div class="sec"><div class="sec-title">需要重点复习<span class="cnt">已加入错题本</span></div><div style="margin-top:10px">');
    wrongs.forEach(function (q) {
      h.push('<div class="card"><div class="card-head" data-goto="' + esc(q.p.id) + '">' +
        '<div class="card-time">' + esc(q.p.timeLabel) + '</div>' +
        '<div class="card-main"><div class="card-title">' + esc(q.p.title) + '</div>' +
        '<div class="card-sub">核心：' + esc(q.p.core) + '</div></div>' +
        '<div class="card-badges">' + levelHtml(q.p.level) + freqHtml(q.p.freq) + '</div>' +
        '</div></div>');
    });
    h.push('</div></div>');
  }
  el.panelBody.innerHTML = h.join('');
}

/* ---------------- 14. 面板：我的标记 ---------------- */
function renderMarked() {
  var favs = POINTS.filter(function (p) { return favSet.has(p.id); });
  var wrongs = POINTS.filter(function (p) { return wrongSet.has(p.id); });
  var keeps = POINTS.filter(function (p) { return (keepMap[p.id] || []).length; });

  var h = [];
  h.push('<div class="list-toolbar"><div class="filter-group">' +
    '<button class="btn" data-act="clearWrong">清空错题本</button>' +
    '<button class="btn" data-act="clearKeep">清除要点高亮</button>' +
    '</div><span class="count-note">标记 ' + favs.length + ' · 错题 ' + wrongs.length + ' · 高亮 ' + keeps.length + '</span></div>');

  h.push('<div class="sec"><div class="sec-title">我标记的重点<span class="cnt">' + favs.length + ' 条</span></div>');
  if (!favs.length) h.push('<div class="empty"><span class="big">☆</span>还没有标记的知识点，在详情页点「标记为重点」即可。</div>');
  else { h.push('<div style="margin-top:10px">'); favs.forEach(function (p) { h.push(cardHtml(p)); }); h.push('</div>'); }
  h.push('</div>');

  h.push('<div class="sec"><div class="sec-title">错题本<span class="cnt">' + wrongs.length + ' 条</span></div>');
  if (!wrongs.length) h.push('<div class="empty"><span class="big">✓</span>暂无错题，保持住。</div>');
  else { h.push('<div style="margin-top:10px">'); wrongs.forEach(function (p) { h.push(cardHtml(p)); }); h.push('</div>'); }
  h.push('</div>');

  if (keeps.length) {
    h.push('<div class="sec"><div class="sec-title">已高亮要点<span class="cnt">' + keeps.length + ' 条</span></div><div style="margin-top:10px">');
    keeps.forEach(function (p) {
      h.push('<div class="card"><div class="card-head" data-goto="' + esc(p.id) + '">' +
        '<div class="card-time">' + esc(p.timeLabel) + '</div>' +
        '<div class="card-main"><div class="card-title">' + esc(p.title) + '</div>' +
        '<div class="card-sub">已高亮 ' + (keepMap[p.id] || []).length + ' 条要点</div></div>' +
        '<div class="card-badges">' + levelHtml(p.level) + '</div></div></div>');
    });
    h.push('</div></div>');
  }
  el.panelBody.innerHTML = h.join('');
  el.panelBody.scrollTop = 0;
}

/* ---------------- 15. 面板调度 ---------------- */
function renderPanel() {
  var t = el.panelTabs.querySelectorAll('.ptab');
  for (var i = 0; i < t.length; i++) {
    t[i].className = 'ptab' + (t[i].getAttribute('data-panel') === state.panel ? ' is-active' : '');
  }
  el.tabNumList.textContent = filteredList().length || '';
  el.tabNumMarked.textContent = favSet.size || '';

  if (state.panel === 'detail') renderDetail();
  else if (state.panel === 'list') renderList();
  else if (state.panel === 'compare') renderCompare();
  else if (state.panel === 'mnemonic') renderMnemonic();
  else if (state.panel === 'quiz') renderQuiz();
  else if (state.panel === 'marked') renderMarked();
}

function switchPanel(name, force) {
  if (state.panel === name && !force) return;
  state.panel = name;
  renderPanel();
}
function refreshAll() {
  renderEraNav();
  renderPeriodChips();
  renderTimeline();
  renderPanel();
}

/* ---------------- 16. 路由与分享 ---------------- */
function baseUrl() {
  return location.href.split('#')[0];
}
/* file:// 下 history.replaceState 会抛 SecurityError，降级为 hash 赋值 */
function setHash(target) {
  if (location.hash === target) return;
  try { history.replaceState(null, '', target); }
  catch (e) { location.hash = target; }
}
function buildShareUrl(hash) {
  return baseUrl() + (hash || '');
}
function shareOptions() {
  var out = [];
  var p = state.activeId ? byId.get(state.activeId) : null;
  if (p) out.push({ id: 'point', label: '本知识点：' + p.title, hash: '#/p/' + p.id });
  if (state.periodId) {
    var c = chById.get(state.periodId);
    if (c) out.push({ id: 'period', label: '本阶段：' + c.name, hash: '#/period/' + c.id });
  }
  if (state.eraId !== 'all') {
    var era = eraById.get(state.eraId);
    if (era) out.push({ id: 'era', label: '本史别：' + era.name, hash: '#/era/' + era.id });
  }
  out.push({ id: 'all', label: '全部内容（时间轴总览）', hash: '#/' });
  return out;
}
var shareCurrent = '#/';
function openShare(defaultId) {
  var opts = shareOptions();
  var pick = opts.filter(function (o) { return o.id === defaultId; })[0] || opts[0];
  shareCurrent = pick.hash;
  el.shareLinkInput.value = buildShareUrl(shareCurrent);
  el.shareDesc.textContent = '复制链接发送给同学，对方打开即可直接看到「' + pick.label + '」，无需登录、无需授权校验。';
  var h = [];
  opts.forEach(function (o) {
    h.push('<button class="share-opt' + (o.hash === shareCurrent ? ' is-active' : '') +
      '" data-hash="' + esc(o.hash) + '" data-label="' + esc(o.label) + '">' + esc(o.label) + '</button>');
  });
  el.shareScope.innerHTML = h.join('');
  el.shareOverlay.hidden = false;
}

function route() {
  var raw = location.hash.replace(/^#\/?/, '');
  var parts = raw.split('/').filter(Boolean);
  if (!parts.length) return;
  var kind = parts[0], val = decodeURIComponent(parts[1] || '');
  if (kind === 'p' && byId.get(val)) {
    selectPoint(val, { panel: 'detail', scroll: true, silent: true });
  } else if (kind === 'period' && chById.get(val)) {
    var c = chById.get(val);
    if (state.eraId !== 'all' && state.eraId !== c.eraId) state.eraId = c.eraId;
    state.periodId = val;
    renderEraNav(); renderPeriodChips();
    scrollToPeriod(val, { instant: true });
    switchPanel('list', true);
  } else if (kind === 'era' && eraById.get(val)) {
    state.eraId = val;
    state.periodId = null;
    renderEraNav(); renderPeriodChips();
    renderTimeline();
    el.tlViewport.scrollLeft = 0;
    renderPanel();
  } else if (kind === 'view' && val) {
    switchPanel(val, true);
  }
}

function selectPoint(id, opt) {
  opt = opt || {};
  var p = byId.get(id);
  if (!p) return;
  state.activeId = id;
  if (state.eraId !== 'all' && state.eraId !== p.eraId) {
    state.eraId = p.eraId;
    renderEraNav();
  }
  state.periodId = p.periodId;
  renderPeriodChips();
  highlightChip(p.periodId);
  renderTimeline();
  if (opt.scroll !== false) scrollToPoint(id);
  if (opt.panel) switchPanel(opt.panel, true);
  else renderPanel();
  if (!opt.silent) {
    var target = '#/p/' + encodeURIComponent(id);
    setHash(target);
  }
}

/* ---------------- 17. 事件绑定 ---------------- */
function bind() {
  /* 史别切换 */
  el.eraNav.addEventListener('click', function (e) {
    var b = e.target.closest('[data-era]');
    if (!b) return;
    state.eraId = b.getAttribute('data-era');
    state.periodId = null;
    renderEraNav(); renderPeriodChips(); renderTimeline();
    el.tlViewport.scrollLeft = 0;
    renderPanel();
    setHash(state.eraId === 'all' ? '#/' : '#/era/' + state.eraId);
  });

  /* 时期跳转 */
  el.periodChips.addEventListener('click', function (e) {
    var b = e.target.closest('[data-pid]');
    if (!b) return;
    var pid = b.getAttribute('data-pid');
    scrollToPeriod(pid);
    if (state.panel !== 'detail') switchPanel('list', true);
  });

  /* 时间轴节点点击 / 拖动 */
  var drag = null;
  el.tlViewport.addEventListener('pointerdown', function (e) {
    if (e.pointerType === 'touch') return;
    drag = { x: e.clientX, left: el.tlViewport.scrollLeft, moved: false };
    el.tlViewport.classList.add('dragging');
  });
  window.addEventListener('pointermove', function (e) {
    if (!drag) return;
    var dx = e.clientX - drag.x;
    if (Math.abs(dx) > 4) drag.moved = true;
    el.tlViewport.scrollLeft = drag.left - dx;
  });
  window.addEventListener('pointerup', function () {
    if (!drag) return;
    var moved = drag.moved;
    drag = null;
    el.tlViewport.classList.remove('dragging');
    el.tlViewport._moved = moved;
  });
  el.tlCanvas.addEventListener('click', function (e) {
    if (el.tlViewport._moved) { el.tlViewport._moved = false; return; }
    var nd = e.target.closest('.node');
    if (!nd) return;
    selectPoint(nd.getAttribute('data-id'));
  });

  /* 滚轮：纵向→横向；Ctrl/⌘→缩放 */
  el.tlViewport.addEventListener('wheel', function (e) {
    if (e.ctrlKey || e.metaKey) {
      e.preventDefault();
      var vp = el.tlViewport;
      var rect = vp.getBoundingClientRect();
      var ratio = clamp((e.clientX - rect.left + vp.scrollLeft) / (parseFloat(el.tlCanvas.style.width) || 1), 0, 1);
      var list = visibleChapters(), acc = 0, ch = list[0];
      var px = ratio * (parseFloat(el.tlCanvas.style.width) || 1);
      for (var i = 0; i < list.length; i++) { if (px >= list[i].x) { ch = list[i]; } }
      var anchor = ch ? { id: ch.id, ratio: 0.5 } : null;
      setScale(state.scale * (e.deltaY < 0 ? 1.15 : 1 / 1.15), anchor);
      return;
    }
    if (Math.abs(e.deltaY) > Math.abs(e.deltaX)) {
      e.preventDefault();
      el.tlViewport.scrollLeft += e.deltaY;
    }
  }, { passive: false });

  /* 键盘 */
  el.tlViewport.addEventListener('keydown', function (e) {
    if (e.key === 'ArrowRight') { el.tlViewport.scrollLeft += 220; e.preventDefault(); }
    else if (e.key === 'ArrowLeft') { el.tlViewport.scrollLeft -= 220; e.preventDefault(); }
    else if (e.key === '+' || e.key === '=') setScale(state.scale * 1.2);
    else if (e.key === '-') setScale(state.scale / 1.2);
  });

  /* 双指缩放 */
  var pinch = null;
  el.tlViewport.addEventListener('touchstart', function (e) {
    if (e.touches.length === 2) {
      pinch = { d: touchDist(e), s: state.scale, a: centerAnchor() };
    }
  }, { passive: true });
  el.tlViewport.addEventListener('touchmove', function (e) {
    if (pinch && e.touches.length === 2) {
      e.preventDefault();
      var d = touchDist(e);
      if (pinch.d > 0) setScale(pinch.s * (d / pinch.d), pinch.a);
    }
  }, { passive: false });
  el.tlViewport.addEventListener('touchend', function () { pinch = null; }, { passive: true });

  /* 缩放按钮 */
  el.zoomIn.addEventListener('click', function () { setScale(state.scale * 1.25); });
  el.zoomOut.addEventListener('click', function () { setScale(state.scale / 1.25); });
  el.zoomFit.addEventListener('click', function () { setScale(fitScale()); });

  /* 缩略导航拖动 */
  var mmDrag = false;
  el.minimap.addEventListener('pointerdown', function (e) {
    mmDrag = true;
    el.minimap.setPointerCapture(e.pointerId);
    mmSeek(e);
  });
  el.minimap.addEventListener('pointermove', function (e) { if (mmDrag) mmSeek(e); });
  el.minimap.addEventListener('pointerup', function () { mmDrag = false; });

  /* 滚动同步 */
  el.tlViewport.addEventListener('scroll', function () { if (syncMinimap._raf) return; syncMinimap._raf = requestAnimationFrame(function () { syncMinimap._raf = 0; syncMinimap(); updateActiveChipByScroll(); }); }, { passive: true });

  window.addEventListener('resize', function () {
    readMetrics();
    renderTimeline();
    renderPanel();
  });

  /* 搜索 */
  el.searchInput.addEventListener('input', function () {
    state.query = el.searchInput.value;
    el.searchClear.className = 'search-clear' + (state.query ? ' on' : '');
    renderSearchPop();
    renderTimeline();
    if (state.panel === 'list' || state.panel === 'compare' || state.panel === 'mnemonic') renderPanel();
  });
  el.searchInput.addEventListener('focus', function () { if (state.query) renderSearchPop(); });
  el.searchInput.addEventListener('keydown', function (e) {
    if (e.key === 'Enter') {
      var first = el.searchPop.querySelector('.sp-item');
      if (first) { selectPoint(first.getAttribute('data-id')); el.searchPop.hidden = true; }
    } else if (e.key === 'Escape') { el.searchPop.hidden = true; }
  });
  el.searchClear.addEventListener('click', function () {
    el.searchInput.value = ''; state.query = '';
    el.searchClear.className = 'search-clear';
    el.searchPop.hidden = true;
    renderTimeline();
    if (state.panel === 'list') renderPanel();
  });
  el.searchPop.addEventListener('click', function (e) {
    var it = e.target.closest('.sp-item');
    if (!it) return;
    selectPoint(it.getAttribute('data-id'));
    el.searchPop.hidden = true;
  });
  document.addEventListener('click', function (e) {
    if (!el.searchPop.hidden && !e.target.closest('.search-box')) el.searchPop.hidden = true;
  });

  /* 面板 tab */
  el.panelTabs.addEventListener('click', function (e) {
    var b = e.target.closest('.ptab');
    if (!b) return;
    switchPanel(b.getAttribute('data-panel'));
  });

  /* 面板内交互（事件委托） */
  el.panelBody.addEventListener('click', onPanelClick);
  el.panelBody.addEventListener('change', function (e) {
    if (e.target.id === 'cmpA') { state.cmpA = e.target.value; renderCompare(); }
    if (e.target.id === 'cmpB') { state.cmpB = e.target.value; renderCompare(); }
  });

  /* 顶部按钮 */
  el.btnQuiz.addEventListener('click', function () { switchPanel('quiz', true); });
  el.btnShare.addEventListener('click', function () { openShare(); });
  el.btnTheme.addEventListener('click', toggleTheme);

  /* 分享浮层 */
  el.shareScope.addEventListener('click', function (e) {
    var b = e.target.closest('.share-opt');
    if (!b) return;
    shareCurrent = b.getAttribute('data-hash');
    el.shareLinkInput.value = buildShareUrl(shareCurrent);
    el.shareDesc.textContent = '复制链接发送给同学，对方打开即可直接看到「' + b.getAttribute('data-label') + '」，无需登录、无需授权校验。';
    var all = el.shareScope.querySelectorAll('.share-opt');
    for (var i = 0; i < all.length; i++) all[i].className = 'share-opt' + (all[i] === b ? ' is-active' : '');
  });
  el.shareCopy.addEventListener('click', function () { copyText(el.shareLinkInput.value); });
  el.shareClose.addEventListener('click', function () { el.shareOverlay.hidden = true; });
  el.shareOverlay.addEventListener('click', function (e) { if (e.target === el.shareOverlay) el.shareOverlay.hidden = true; });

  /* 路由 */
  window.addEventListener('hashchange', route);

  /* 全局快捷键 */
  document.addEventListener('keydown', function (e) {
    if (e.key === '/' && document.activeElement !== el.searchInput) {
      e.preventDefault(); el.searchInput.focus();
    }
    if (e.key === 'Escape') {
      if (!el.shareOverlay.hidden) el.shareOverlay.hidden = true;
      else if (!el.searchPop.hidden) el.searchPop.hidden = true;
    }
  });
}

function touchDist(e) {
  var a = e.touches[0], b = e.touches[1];
  return Math.hypot(a.clientX - b.clientX, a.clientY - b.clientY);
}
function mmSeek(e) {
  var r = el.minimap.getBoundingClientRect();
  var ratio = clamp((e.clientX - r.left) / r.width, 0, 1);
  var contentW = parseFloat(el.tlCanvas.style.width) || 1;
  var vp = el.tlViewport;
  vp.scrollLeft = ratio * contentW - vp.clientWidth / 2;
  syncMinimap();
}
function updateActiveChipByScroll() {
  var vp = el.tlViewport;
  var cx = vp.scrollLeft + vp.clientWidth / 2;
  var list = visibleChapters(), cur = null;
  for (var i = 0; i < list.length; i++) {
    if (cx >= list[i].x && cx < list[i].x + list[i].width) { cur = list[i]; break; }
    if (cx >= list[i].x) cur = list[i];
  }
  if (cur && cur.id !== state.periodId) {
    state.periodId = cur.id;
    highlightChip(cur.id);
  }
}

function onPanelClick(e) {
  var gt = e.target.closest('[data-goto]');
  if (gt) { selectPoint(gt.getAttribute('data-goto')); return; }

  var tg = e.target.closest('[data-toggle]');
  if (tg) {
    var card = tg.closest('.card');
    var body = card.querySelector('.card-body');
    var open = !body.hidden;
    body.hidden = open;
    card.className = 'card' + (open ? '' : ' open');
    return;
  }

  var keep = e.target.closest('[data-keep]');
  if (keep) {
    var idx = Number(keep.getAttribute('data-keep'));
    var cardEl = keep.closest('.card');
    var pid = cardEl ? cardEl.getAttribute('data-cid') : state.activeId;
    if (!pid) return;
    var arr = (keepMap[pid] || []).slice();
    var at = arr.indexOf(idx);
    if (at >= 0) arr.splice(at, 1); else arr.push(idx);
    if (arr.length) keepMap[pid] = arr; else delete keepMap[pid];
    saveKeep();
    keep.className = 'markable' + (arr.indexOf(idx) >= 0 ? ' keep' : '');
    return;
  }

  var lnk = e.target.closest('[data-pid]');
  if (lnk && lnk.tagName === 'A') {
    e.preventDefault();
    scrollToPeriod(lnk.getAttribute('data-pid'));
    return;
  }

  /* 筛选按钮 */
  var f = e.target.closest('[data-freq]');
  if (f) { state.listFreq = Number(f.getAttribute('data-freq')); renderList(); return; }
  var l = e.target.closest('[data-level]');
  if (l) { state.listLevel = l.getAttribute('data-level'); renderList(); return; }
  var so = e.target.closest('[data-sort]');
  if (so) { state.listSort = so.getAttribute('data-sort'); renderList(); return; }
  var qr = e.target.closest('[data-qrange]');
  if (qr) { state.quizRange = qr.getAttribute('data-qrange'); renderQuizSetup(); return; }
  var qm = e.target.closest('[data-qmode]');
  if (qm) { state.quizMode = qm.getAttribute('data-qmode'); renderQuizSetup(); return; }
  var qc = e.target.closest('[data-qcount]');
  if (qc) { state.quizCount = Number(qc.getAttribute('data-qcount')); renderQuizSetup(); return; }

  /* 抽背答题 */
  var opt = e.target.closest('[data-opt]');
  if (opt && QS && QS.qs[QS.i] && QS.qs[QS.i].type === 'choice') {
    var q = QS.qs[QS.i];
    if (q.picked) return;
    q.picked = opt.getAttribute('data-opt');
    if (q.picked === q.p.id) {
      QS.right++; stat.right++;
      wrongSet.delete(q.p.id); saveWrong();
    } else {
      QS.wrong++; wrongSet.add(q.p.id); saveWrong();
    }
    stat.done++; LS.set(K_STAT, stat);
    renderQuiz();
    el.tabNumMarked.textContent = favSet.size || '';
    return;
  }

  var act = e.target.closest('[data-act]');
  if (!act) return;
  var a = act.getAttribute('data-act');
  var id = act.getAttribute('data-id') || state.activeId;

  if (a === 'fav') {
    if (!id) return;
    if (favSet.has(id)) favSet.delete(id); else favSet.add(id);
    saveFav();
    toast(favSet.has(id) ? '已标记为重点' : '已取消标记');
    renderTimeline();
    renderPanel();
  } else if (a === 'share') {
    if (id && id !== state.activeId) selectPoint(id, { silent: true, scroll: false });
    openShare(id ? 'point' : undefined);
  } else if (a === 'detail') {
    selectPoint(id, { panel: 'detail' });
  } else if (a === 'cmp') {
    if (state.cmpA !== id && state.cmpB !== id) {
      if (!state.cmpA) state.cmpA = id; else state.cmpB = id;
    }
    switchPanel('compare', true);
    renderCompare();
    toast('已加入对比台');
  } else if (a === 'cmpSwap') {
    var t = state.cmpA; state.cmpA = state.cmpB; state.cmpB = t; renderCompare();
  } else if (a === 'unwrong') {
    wrongSet.delete(id); saveWrong(); renderPanel(); toast('已从错题本移除');
  } else if (a === 'clearWrong') {
    wrongSet.clear(); saveWrong(); renderPanel(); toast('错题本已清空');
  } else if (a === 'clearKeep') {
    keepMap = {}; saveKeep(); renderPanel(); toast('要点高亮已清除');
  } else if (a === 'quiz' && id) {
    state.quizRange = 'all';
    QS = { qs: [{ type: 'recall', p: byId.get(id), revealed: false, ok: null }], i: 0, right: 0, wrong: 0, finished: false };
    switchPanel('quiz', true);
  } else if (a === 'qStart') {
    buildQuiz();
  } else if (a === 'qBack') {
    QS = null; renderQuizSetup();
  } else if (a === 'qNext') {
    QS.i++;
    if (QS.i >= QS.qs.length) QS.finished = true;
    renderQuiz();
  } else if (a === 'qQuit') {
    QS.finished = true; renderQuiz();
  } else if (a === 'qShow') {
    QS.qs[QS.i].revealed = true; renderQuiz();
  } else if (a === 'qOpen') {
    selectPoint(QS.qs[QS.i].p.id, { panel: 'detail' });
  } else if (a === 'qOk' || a === 'qNo') {
    var cur = QS.qs[QS.i];
    if (cur.ok !== null) return;
    cur.ok = (a === 'qOk');
    if (cur.ok) { QS.right++; stat.right++; wrongSet.delete(cur.p.id); saveWrong(); }
    else { QS.wrong++; wrongSet.add(cur.p.id); saveWrong(); }
    stat.done++; LS.set(K_STAT, stat);
    QS.i++;
    if (QS.i >= QS.qs.length) QS.finished = true;
    renderQuiz();
  }
}

function renderSearchPop() {
  var q = state.query.trim().toLowerCase();
  if (!q) { el.searchPop.hidden = true; return; }
  var hits = POINTS.filter(function (p) { return p.search.indexOf(q) >= 0; }).slice(0, 40);
  var h = [];
  if (!hits.length) h.push('<div class="sp-empty">没有匹配的知识点</div>');
  hits.forEach(function (p) {
    h.push('<div class="sp-item" data-id="' + esc(p.id) + '">' +
      '<span class="sp-time">' + esc(p.timeLabel) + '</span>' +
      '<span class="sp-title">' + hl(p.title) + '</span>' +
      '<span class="sp-period">' + esc(p.period) + '</span></div>');
  });
  el.searchPop.innerHTML = h.join('');
  el.searchPop.hidden = false;
}

function copyText(text) {
  function fallback() {
    var ta = document.createElement('textarea');
    ta.value = text;
    ta.style.position = 'fixed'; ta.style.opacity = '0';
    document.body.appendChild(ta);
    ta.select();
    var ok = false;
    try { ok = document.execCommand('copy'); } catch (e) {}
    document.body.removeChild(ta);
    toast(ok ? '链接已复制，粘贴给同学即可' : '复制失败，请手动长按链接复制');
  }
  if (navigator.clipboard && navigator.clipboard.writeText) {
    navigator.clipboard.writeText(text).then(function () {
      toast('链接已复制，粘贴给同学即可');
    }).catch(fallback);
  } else fallback();
}

function toggleTheme() {
  var cur = document.documentElement.getAttribute('data-theme') === 'dark' ? 'dark' : 'light';
  var next = cur === 'dark' ? 'light' : 'dark';
  document.documentElement.setAttribute('data-theme', next);
  LS.set(K_THEME, next);
}

/* ---------------- 18. 启动 ---------------- */
function boot() {
  var saved = LS.get(K_THEME, null);
  if (!saved && window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) saved = 'dark';
  if (saved) document.documentElement.setAttribute('data-theme', saved);

  if (!POINTS.length) {
    el.panelBody.innerHTML = '<div class="empty"><span class="big">!</span>知识点数据未加载成功，请检查 assets/js/data/ 目录下的数据文件。</div>';
    return;
  }

  readMetrics();
  state.scale = clamp(fitScale(), MIN_SCALE, MAX_SCALE);
  renderEraNav();
  renderPeriodChips();
  renderTimeline();
  el.zoomVal.textContent = Math.round(state.scale * 100) + '%';
  updateZoomButtons();
  renderPanel();
  bind();

  if (location.hash) route();

  window.HIST_APP = {
    state: state,
    points: POINTS,
    open: function (id) { selectPoint(id); },
    share: function (id) { openShare(id); }
  };
}

if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
else boot();

})();
