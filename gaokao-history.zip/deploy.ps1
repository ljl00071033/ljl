# ============================================================
#  GitHub Pages 一键部署脚本（PowerShell）
#  ------------------------------------------------------------
#  使用前提：
#    1. 你已在 https://github.com/new 创建了一个公开空仓库，
#       名字就叫 gaokao-history（不要勾选 "Add a README file"）
#    2. 你已登录过这个仓库的推送（Windows 凭据管理器里有 token
#       或 git credential manager 可用），首次推送时会弹认证框
#
#  运行：右键 → 使用 PowerShell 运行，或直接双击
# ============================================================

$repoName = "gaokao-history"

Write-Host ""
Write-Host "=== 高考历史速记系统 · GitHub Pages 部署 ===" -ForegroundColor Cyan
Write-Host ""

# 1. 检查 git 仓库
if (-not (Test-Path ".git")) {
    Write-Host "✗ 当前目录不是 git 仓库，先手动运行：" -ForegroundColor Red
    Write-Host "    git init -b main && git add -A && git commit -m 'init'" -ForegroundColor Gray
    Read-Host "按 Enter 退出"
    exit 1
}

# 2. 收集 GitHub 用户名
$owner = Read-Host "请输入你的 GitHub 用户名（例如 octocat）"
if ([string]::IsNullOrWhiteSpace($owner)) { Write-Host "✗ 用户名不能为空" -ForegroundColor Red; exit 1 }

# 3. 设置 remote
$remoteUrl = "https://github.com/$owner/$repoName.git"
$existing = git remote 2>$null
if ($existing -match "origin") {
    git remote set-url origin $remoteUrl
    Write-Host "· 已更新 origin → $remoteUrl" -ForegroundColor Yellow
} else {
    git remote add origin $remoteUrl
    Write-Host "· 已添加 origin → $remoteUrl" -ForegroundColor Green
}

# 4. 检查工作区是否干净
$dirty = $(git status --porcelain).Length
if ($dirty -gt 0) {
    Write-Host "· 有未提交改动，自动提交..." -ForegroundColor Yellow
    git add -A
    git commit -m "update: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')"
}

# 5. 推送
Write-Host ""
Write-Host "→ 正在推送到 $remoteUrl  ..." -ForegroundColor Cyan
Write-Host "  （首次推送时会弹出 GitHub 登录框，请用你的 GitHub 账号 + Personal Access Token 登录）" -ForegroundColor Gray
Write-Host ""

git push -u origin main 2>&1 | Tee-Object -Variable pushOut

if ($LASTEXITCODE -eq 0) {
    Write-Host ""
    Write-Host "=== 推送成功 ===" -ForegroundColor Green
    Write-Host ""
    Write-Host "接下来只需在浏览器完成两步：" -ForegroundColor White
    Write-Host "  1. 打开 https://github.com/$owner/$repoName/settings/pages" -ForegroundColor Yellow
    Write-Host "  2. Source 选 'Deploy from a branch'，Branch 选 'main' / '/ (root)'，Save" -ForegroundColor Yellow
    Write-Host ""
    Write-Host "部署完成后访问地址：" -ForegroundColor White
    Write-Host "    https://$owner.github.io/$repoName/" -ForegroundColor Cyan
    Write-Host ""
    Write-Host "分享链接格式示例：" -ForegroundColor White
    Write-Host "    https://$owner.github.io/$repoName/#/p/cnm-011   （直达辛亥革命知识点）" -ForegroundColor Gray
    Write-Host "    https://$owner.github.io/$repoName/#/period/tang  （直达唐朝阶段）" -ForegroundColor Gray
} else {
    Write-Host ""
    Write-Host "✗ 推送失败。常见原因：" -ForegroundColor Red
    Write-Host "   - 仓库还没在 GitHub 上创建 → 去 https://github.com/new 建一个空仓库" -ForegroundColor Gray
    Write-Host "   - 认证失败 → 用 GitHub Settings → Developer settings → Personal access tokens 生成一个" -ForegroundColor Gray
    Write-Host "                  ，scope 勾选 repo，推送时粘贴进去" -ForegroundColor Gray
    Write-Host "   - 网络问题 → 多试一次" -ForegroundColor Gray
}

Write-Host ""
Read-Host "按 Enter 关闭窗口"
